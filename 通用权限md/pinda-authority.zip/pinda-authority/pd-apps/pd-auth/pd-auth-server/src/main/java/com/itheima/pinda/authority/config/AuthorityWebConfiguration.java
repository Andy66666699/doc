package com.itheima.pinda.authority.config;

import com.itheima.pinda.common.config.BaseConfig;
import org.springframework.context.annotation.Configuration;

/**
 * 公共基础配置
 */
@Configuration
public class AuthorityWebConfiguration extends BaseConfig{
}
